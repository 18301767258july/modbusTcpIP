﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SlaveADAM_modbusTCPIPv1._2
{


        public class MyAttr:Attribute
        {
            public string Msg { get; set; }
        }

  

        public delegate void MyTestDelegate (object sender,MyAttr e);

        public class MyClass 
        {

            public string Name { get; set; }

            public event MyTestDelegate MyEvent ;

            //
            protected virtual void Call(MyAttr e) 
            {
                if (MyEvent != null) 
                {
                    MyEvent(this, e);
                }
            }

            public void Fun()
            {
                MyAttr e = new MyAttr();
                e.Msg = "event coming";
                Call(e);
            }
        }
}