﻿namespace SlaveADAM_modbusTCPIPv1._2
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label101 = new System.Windows.Forms.Label();
            this.tbxIP = new System.Windows.Forms.TextBox();
            this.tbxID = new System.Windows.Forms.TextBox();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.cbxFunCode = new System.Windows.Forms.ComboBox();
            this.label104 = new System.Windows.Forms.Label();
            this.tbxIOCount = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(1046, 37);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(18, 12);
            this.label101.TabIndex = 102;
            this.label101.Text = "IP:";
            // 
            // tbxIP
            // 
            this.tbxIP.Location = new System.Drawing.Point(1072, 30);
            this.tbxIP.Name = "tbxIP";
            this.tbxIP.Size = new System.Drawing.Size(100, 22);
            this.tbxIP.TabIndex = 103;
            // 
            // tbxID
            // 
            this.tbxID.Location = new System.Drawing.Point(1072, 63);
            this.tbxID.Name = "tbxID";
            this.tbxID.Size = new System.Drawing.Size(100, 22);
            this.tbxID.TabIndex = 104;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(1046, 66);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(20, 12);
            this.label102.TabIndex = 105;
            this.label102.Text = "ID:";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(989, 104);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(77, 12);
            this.label103.TabIndex = 106;
            this.label103.Text = "Function Code:";
            // 
            // cbxFunCode
            // 
            this.cbxFunCode.FormattingEnabled = true;
            this.cbxFunCode.Items.AddRange(new object[] {
            "01 Coil  Status  (0x)",
            "02 Input  Status  (1x)"});
            this.cbxFunCode.Location = new System.Drawing.Point(1072, 101);
            this.cbxFunCode.Name = "cbxFunCode";
            this.cbxFunCode.Size = new System.Drawing.Size(121, 20);
            this.cbxFunCode.TabIndex = 107;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(1019, 141);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(52, 12);
            this.label104.TabIndex = 108;
            this.label104.Text = "IO Count:";
            // 
            // tbxIOCount
            // 
            this.tbxIOCount.Location = new System.Drawing.Point(1072, 138);
            this.tbxIOCount.Name = "tbxIOCount";
            this.tbxIOCount.Size = new System.Drawing.Size(100, 22);
            this.tbxIOCount.TabIndex = 109;
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(2, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(981, 479);
            this.groupBox1.TabIndex = 110;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(1085, 200);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 23);
            this.btnConnect.TabIndex = 111;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1215, 485);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tbxIOCount);
            this.Controls.Add(this.label104);
            this.Controls.Add(this.cbxFunCode);
            this.Controls.Add(this.label103);
            this.Controls.Add(this.label102);
            this.Controls.Add(this.tbxID);
            this.Controls.Add(this.tbxIP);
            this.Controls.Add(this.label101);
            this.Name = "Form1";
            this.Text = "ADAM";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.TextBox tbxIP;
        private System.Windows.Forms.TextBox tbxID;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.ComboBox cbxFunCode;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.TextBox tbxIOCount;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnConnect;

    }
}

