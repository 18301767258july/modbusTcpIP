﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;

namespace SlaveADAM_modbusTCPIPv1._2
{
    public class XMLSerializer
    {
        /// <summary>
        /// 反序列化
        /// </summary>
        /// <param name="type"></param>
        /// <param name="xmlstr"></param>
        /// <returns></returns>
        public static object Deserialize(Type type, string xmlstr)
        {
            try
            {
                using (StringReader reader = new StringReader(xmlstr))
                {
                    XmlSerializer xmlDes = new XmlSerializer(type);
                    return xmlDes.Deserialize(reader);
                }
            }
            catch
            { return null; }
        }
        /// <summary>
        /// 反序列化
        /// </summary>
        /// <param name="type"></param>
        /// <param name="stream"></param>
        /// <returns></returns>
        public static object Deserialize(Type type, Stream stream)
        {
            XmlSerializer xmlDes = new XmlSerializer(type);
            return xmlDes.Deserialize(stream);
        }
        /// <summary>
        /// 序列化
        /// </summary>
        /// <param name="type"></param>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string Serializer(Type type, object obj)
        {
            FileStream stream = new FileStream(System.Environment.CurrentDirectory + "\\config.xml", FileMode.OpenOrCreate);
            XmlSerializer xml = new XmlSerializer(type);
            try
            {
                //序列化对象
                xml.Serialize(stream, obj);
            }
            catch
            { }

            stream.Position = 0;
            StreamReader reader = new StreamReader(stream);
            string str = reader.ReadToEnd();
            reader.Dispose();
            stream.Dispose();

            return str;
        }
    }
}
