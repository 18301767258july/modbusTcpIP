﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace SlaveADAM_modbusTCPIPv1._2
{
    public partial class Form1 : Form
    {
        List<TextBox> gbxIO = new List<TextBox>();
        Slave slave;
        public Form1()
        {
            InitializeComponent();
            slave = new Slave();
            slave.UpdateUI+= new Action<ModbusIO[]>(UpdateData);
            slave.ReceiveUI += new Action<ModbusIO[]>(SendUIDataToSlave);
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            cbxFunCode.SelectedIndex = 0;
        }

        private void DisplayIOCount(int num)
        {
            for (int i = 0; i < num; i++)
            {
                int row = i / 10;
                int column = i % 10;
                GroupBox gbx = new GroupBox();
                gbx.SetBounds(7 + column * 100, 45 * row, 90, 40);
                Label cb = new Label();
                TextBox tb = new TextBox();
                cb.Text = "IO" + i.ToString() + ":";
                cb.SetBounds(0, 17, 35, 20);
                cb.Left = 10;
                tb.Text = "";

                tb.KeyPress += LimitInput;
                tb.SetBounds(45, 13, 30, 25);
                gbx.Controls.Add(cb);
                gbx.Controls.Add(tb);
                gbxIO.Add(tb);
                groupBox1.Controls.Add(gbx);
            }
        }

        private void btnConnect_Click_1(object sender, EventArgs e)
        {
            DisplayIOCount(Convert.ToInt32(tbxIOCount.Text));
            slave.connect(tbxIP.Text, Convert.ToInt32(tbxIOCount.Text), Convert.ToInt32(tbxID.Text));
            
            if (cbxFunCode.SelectedIndex == 0)
            {
                Thread thread = new Thread(new ParameterizedThreadStart(slave.HandleDataThread));
                thread.IsBackground = true;
                thread.Start(FunctionCode.ReadCoils);
            }
            else
            {
                Thread thread = new Thread(new ParameterizedThreadStart(slave.HandleDataThread));
                thread.IsBackground = true;
                thread.Start(FunctionCode.ReadDiscreteInput);
            }  
        }
       
        
        void UpdateData(ModbusIO[] value)
        {
            //跨线程    有问题
            for (int i = 0; i < Convert.ToInt32(tbxIOCount.Text);i++ )
            {
                if (gbxIO[i].InvokeRequired)
                {
                    Action<int> actionDelegate = (x) => { this.gbxIO[i].Text = x.ToString(); };
                    this.gbxIO[i].Invoke(actionDelegate, value[i].Value); 
                }
                else
                {
                    gbxIO[i].Text = value[i].Value.ToString();
                }
            }
        }


        void SendUIDataToSlave(ModbusIO[] data)
        {
            for(int i=0;i<Convert.ToInt32(tbxIOCount.Text);i++)
            {
             //   gbxIO[i].TextChanged += LimitInput;

                data[i].Value = Convert.ToInt32(gbxIO[i].Text);
            }
            
        }
        public void LimitInput(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar != 48 && e.KeyChar != 49)
            {
                e.Handled = true;
                MessageBox.Show("输入有误，请重新输入！");

            }
            else
            {
                e.Handled = false;
            }
        }


      
    }
    
}
