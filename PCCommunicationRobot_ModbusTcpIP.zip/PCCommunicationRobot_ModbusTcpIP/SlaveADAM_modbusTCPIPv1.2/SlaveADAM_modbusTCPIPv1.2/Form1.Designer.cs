﻿namespace SlaveADAM_modbusTCPIPv1._2
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label101 = new System.Windows.Forms.Label();
            this.tbxIP = new System.Windows.Forms.TextBox();
            this.tbxID = new System.Windows.Forms.TextBox();
            this.label102 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnMove = new System.Windows.Forms.Button();
            this.cbxToStation = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbxStartStation = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbxStartNum = new System.Windows.Forms.TextBox();
            this.tbxToNum = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(38, 24);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(18, 12);
            this.label101.TabIndex = 102;
            this.label101.Text = "IP:";
            // 
            // tbxIP
            // 
            this.tbxIP.Location = new System.Drawing.Point(66, 21);
            this.tbxIP.Name = "tbxIP";
            this.tbxIP.Size = new System.Drawing.Size(100, 22);
            this.tbxIP.TabIndex = 103;
            // 
            // tbxID
            // 
            this.tbxID.Location = new System.Drawing.Point(66, 70);
            this.tbxID.Name = "tbxID";
            this.tbxID.Size = new System.Drawing.Size(100, 22);
            this.tbxID.TabIndex = 104;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(40, 73);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(20, 12);
            this.label102.TabIndex = 105;
            this.label102.Text = "ID:";
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(2, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(981, 479);
            this.groupBox1.TabIndex = 110;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(66, 116);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 23);
            this.btnConnect.TabIndex = 111;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click_1);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbxToNum);
            this.groupBox2.Controls.Add(this.tbxStartNum);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.btnMove);
            this.groupBox2.Controls.Add(this.cbxToStation);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.cbxStartStation);
            this.groupBox2.Location = new System.Drawing.Point(989, 214);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(224, 190);
            this.groupBox2.TabIndex = 112;
            this.groupBox2.TabStop = false;
            // 
            // btnMove
            // 
            this.btnMove.Location = new System.Drawing.Point(79, 150);
            this.btnMove.Name = "btnMove";
            this.btnMove.Size = new System.Drawing.Size(75, 23);
            this.btnMove.TabIndex = 113;
            this.btnMove.Text = "Move";
            this.btnMove.UseVisualStyleBackColor = true;
            this.btnMove.Click += new System.EventHandler(this.button1_Click);
            // 
            // cbxToStation
            // 
            this.cbxToStation.FormattingEnabled = true;
            this.cbxToStation.Items.AddRange(new object[] {
            "unpair",
            "op10",
            "NG1",
            "NG2",
            "output"});
            this.cbxToStation.Location = new System.Drawing.Point(66, 85);
            this.cbxToStation.Name = "cbxToStation";
            this.cbxToStation.Size = new System.Drawing.Size(75, 20);
            this.cbxToStation.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "ToStation:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "StartStation:";
            // 
            // cbxStartStation
            // 
            this.cbxStartStation.FormattingEnabled = true;
            this.cbxStartStation.Items.AddRange(new object[] {
            "input",
            "unpair",
            "op10",
            ""});
            this.cbxStartStation.Location = new System.Drawing.Point(66, 34);
            this.cbxStartStation.Name = "cbxStartStation";
            this.cbxStartStation.Size = new System.Drawing.Size(67, 20);
            this.cbxStartStation.TabIndex = 2;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnConnect);
            this.groupBox3.Controls.Add(this.tbxID);
            this.groupBox3.Controls.Add(this.label102);
            this.groupBox3.Controls.Add(this.label101);
            this.groupBox3.Controls.Add(this.tbxIP);
            this.groupBox3.Location = new System.Drawing.Point(1003, 30);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 156);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(139, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 12);
            this.label3.TabIndex = 114;
            this.label3.Text = "StartNum:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(147, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 12);
            this.label4.TabIndex = 115;
            this.label4.Text = "ToNum:";
            // 
            // tbxStartNum
            // 
            this.tbxStartNum.Location = new System.Drawing.Point(193, 31);
            this.tbxStartNum.Name = "tbxStartNum";
            this.tbxStartNum.Size = new System.Drawing.Size(25, 22);
            this.tbxStartNum.TabIndex = 113;
            // 
            // tbxToNum
            // 
            this.tbxToNum.Location = new System.Drawing.Point(197, 85);
            this.tbxToNum.Name = "tbxToNum";
            this.tbxToNum.Size = new System.Drawing.Size(21, 22);
            this.tbxToNum.TabIndex = 116;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1215, 485);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "ADAM";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.TextBox tbxIP;
        private System.Windows.Forms.TextBox tbxID;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cbxToStation;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbxStartStation;
        private System.Windows.Forms.Button btnMove;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox tbxToNum;
        private System.Windows.Forms.TextBox tbxStartNum;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;

    }
}

