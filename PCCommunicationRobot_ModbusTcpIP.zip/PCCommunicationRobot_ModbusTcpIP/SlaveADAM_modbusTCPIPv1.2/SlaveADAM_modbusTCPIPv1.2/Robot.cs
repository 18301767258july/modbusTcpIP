﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace SlaveADAM_modbusTCPIPv1._2
{
    public class Robot
    {
        private Log log;
        public Slave slave;
        private Thread thread;
        private int iocount=62;
        public event Action<ModbusIO[]>UpdateUI;
        public event Action<ModbusIO[]> ReceiveUI;
        public string startStation;
        public int startNum;
        public string toStation;
        public int toNum;
        public Robot()
        {
            slave = new Slave();
            log = new Log();
            
        }
        public void Connect(string ip,int port)
        {
            slave.connect(ip, iocount, port);
            if (UpdateUI != null)
            {
                UpdateUI(slave.io);
            }
            HandleDataThread();
        }
        private void HandleDataThread()
        {

            thread = new Thread(HandleData);
            thread.IsBackground = true;
            thread.Start();
        }
        private void HandleData()
        {
            while (true)
            {
                if (ReceiveUI != null)
                {
                    ReceiveUI(slave.io);
                }
                slave.HandleData();
                if (UpdateUI != null)
                {
                    UpdateUI(slave.io);
                }
            }
        }
        /// <summary>
        /// move robot
        /// </summary>
        /// <param name="startStation">start station</param>
        /// <param name="startNum"> start station number</param>
        /// <param name="toStation">end station</param>
        /// <param name="toNum">end station number</param>
        /// <returns>success return true , fail return false</returns>
        /// 
        public bool Move(string startStation, int startNum, string toStation, int toNum)
        {
            ModbusIO temp = null;
            if (slave.io[60].Value == 0)
            {
                switch (toStation)
                {
                    case "unpair"://input to unpair
                        #region input to unpair
                        if (startStation == "input")
                        {
                            if (toNum >= 1 && toNum <= 15)//input to A unpair
                            {
                                slave.io[3].Value = 1;
                                slave.io[4].Value = 0;
                                slave.io[toNum + 10 - 1].Value = 1;
                                if (UpdateUI != null)
                                {
                                    UpdateUI(slave.io);
                                }
                                temp = slave.io[toNum + 10 - 1];
                            }
                            else if (toNum >= 16 && toNum <= 30)//input to B unpair
                            {
                                slave.io[3].Value = 0;
                                slave.io[4].Value = 1;
                                slave.io[toNum - 6].Value = 1;
                                if (UpdateUI != null)
                                {
                                    UpdateUI(slave.io);
                                }
                                temp = slave.io[toNum - 6];
                            }
                            else
                            {
                                log.WriteLog("destination number error,please enter number bewteen 1 and 30 .");
                                return false;
                            }
                        }
                        else
                        {
                            log.WriteLog("start address and destination address mismatch.");
                            return false;
                        }
                        #endregion
                        break;
                    case "op10": //unpair to op10
                        #region  unpair to op10
                        if (startStation == "unpair")
                        {
                            if (startNum >= 1 && startNum <= 15)  //A unpair to op10 1
                            {
                                if (toNum == 1)
                                {
                                    slave.io[3].Value = 1;
                                    slave.io[4].Value = 0;
                                    slave.io[25 + startNum - 1].Value = 1;
                                    if (UpdateUI != null)
                                    {
                                        UpdateUI(slave.io);
                                    }
                                    temp = slave.io[25 + startNum - 1];
                                }
                            }
                            else if (startNum >= 16 && startNum <= 30) //B unpair to op10 2
                            {
                                slave.io[3].Value = 0;
                                slave.io[4].Value = 1;
                                slave.io[startNum + 9].Value = 1;
                                if (UpdateUI != null)
                                {
                                    UpdateUI(slave.io);
                                }
                                temp = slave.io[25 + startNum + 9];
                            }
                            else
                            {
                                log.WriteLog("destination number error,please enter number bewteen 1 and 30 .");
                            }
                        }
                        else
                        {
                            log.WriteLog("start address and destination address mismatch.");
                            return false;
                        }
                        #endregion
                        break;
                    case "NG1": //unpair to NG1
                        #region  unpair to NG1
                        if (startStation == "unpair")
                        {
                            if (startNum >= 1 && startNum <= 15) //A
                            {
                                slave.io[3].Value = 1;
                                slave.io[4].Value = 0;
                                slave.io[39 + startNum].Value = 1;
                                if (UpdateUI != null)
                                {
                                    UpdateUI(slave.io);
                                }
                                temp = slave.io[39 + startNum];
                            }
                            else if (startNum >= 16 && startNum <= 30)//B
                            {
                                slave.io[3].Value = 0;
                                slave.io[4].Value = 1;
                                slave.io[24 + startNum].Value = 1;
                                if (UpdateUI != null)
                                {
                                    UpdateUI(slave.io);
                                }
                                temp = slave.io[24 + startNum];
                            }
                            else
                            {
                                log.WriteLog("destination number error,please enter number bewteen 1 and 30 .");
                                return false;
                            }
                        }
                        else
                        {
                            log.WriteLog("start address and destination address mismatch.");
                            return false;
                        }
                        #endregion
                        break;
                    case "NG2":
                        #region op10  NG2
                        if (startStation == "op10")
                        {
                            if (startNum == 1)//A op10
                            {
                                slave.io[3].Value = 1;
                                slave.io[4].Value = 0;
                                slave.io[56].Value = 1;
                                if (UpdateUI != null)
                                {
                                    UpdateUI(slave.io);
                                }
                                temp = slave.io[56];
                            } if (startNum == 2)//B  op10
                            {
                                slave.io[3].Value = 0;
                                slave.io[4].Value = 1;
                                slave.io[56].Value = 1;
                                if (UpdateUI != null)
                                {
                                    UpdateUI(slave.io);
                                }
                                temp = slave.io[56];
                            }
                            else
                            {
                                log.WriteLog("start address and destination address mismatch.");
                                return false;
                            }
                        }
                        else
                        {
                            log.WriteLog("start address and destination address mismatch.");
                            return false;
                        }
                        #endregion
                        break;
                    case "output": //op10  to output
                        #region op10 to output
                        if (startStation == "op10")
                        {
                            if (startNum == 1)//A
                            {
                                slave.io[3].Value = 1;
                                slave.io[4].Value = 0;
                                slave.io[55].Value = 1;
                                if (UpdateUI != null)
                                {
                                    UpdateUI(slave.io);
                                }
                                temp = slave.io[55];
                            }
                            else if (startNum == 2)//B
                            {
                                slave.io[3].Value = 0;
                                slave.io[4].Value = 1;
                                slave.io[55].Value = 1;
                                if (UpdateUI != null)
                                {
                                    UpdateUI(slave.io);
                                }
                                temp = slave.io[55];
                            }
                            else
                            {
                                log.WriteLog("start address and destination address mismatch.");
                                return false;
                            }
                        }
                        else
                        {
                            log.WriteLog("start address and destination address mismatch.");
                            return false;
                        }
                        #endregion
                        break;
                }
                Thread.Sleep(680);
                ResetRobotMoveBit();
                //robot开始动作，等待动作完成
                while (slave.io[61].Value == 0)
                {

                }
                if (slave.io[61].Value == 1)
                {
                    temp.Value = 0;
                }
                return true;
            }
            else
            {
                return false;
            }
            
        }
        //触发robot 动作
        private void ResetRobotMoveBit()
        {
            slave.io[3].Value = 1;
            if (UpdateUI != null)
            {
                UpdateUI(slave.io);
            }
            Thread.Sleep(1000);
            slave.io[3].Value = 0;
            if (UpdateUI != null)
            {
                UpdateUI(slave.io);
            }

        }
        public bool Pause()
        {
            slave.io[2].Value = 1;
            if (UpdateUI != null)
            {
                UpdateUI(slave.io);
            }
            return true;
        }
        public bool Reset()
        {
            slave.io[1].Value = 1;
            if (UpdateUI != null)
            {
                UpdateUI(slave.io);
            }
            return true;
        }
        public void Action()
        {
            Move(startStation, startNum, toStation, toNum);
        }
    }
}
