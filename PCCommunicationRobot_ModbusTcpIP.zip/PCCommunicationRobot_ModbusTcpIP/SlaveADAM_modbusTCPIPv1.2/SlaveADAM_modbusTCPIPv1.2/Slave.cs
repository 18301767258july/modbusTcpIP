﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Threading;

namespace SlaveADAM_modbusTCPIPv1._2
{
  
    public class Slave
    {
        public ModbusIO[] io;
        Log log;
        private SocketServer SlaveServer;
        
        public Slave()
        { }

        // device id
        public int Port
        {
            set;
            get;
        }
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="ip">ip</param>
        /// <param name="ioCount">IO个数</param>
        public void connect(string ip, int ioCount, int port)
        {
            this.Port = port;
            this.SlaveServer = new SocketServer(ip, 502);
            log = new Log();
            log.WriteLog(ip + "连接成功");
            io = new ModbusIO[ioCount];
            for (int i = 0; i < ioCount; i++)
            {
                io[i] = new ModbusIO();
            }
            LoadDataFromXML(ioCount);

            //if (UpdateUI != null)
            //{
            //    this.UpdateUI(io);
            //}
        }

        
        public void HandleData()
        {
            //接收数据
           // while (true)
           // {
                byte[] data = SlaveServer.ReceiveDataReturnByteArr();
                string receiveMes = BitConverter.ToString(data).Replace('-', ' ');
                log.WriteLog("rece data:" + receiveMes);
                //处理数据
                switch (Convert.ToInt32(data[7]))
                {
                    case 05:
                        WriteCoil(data);
                        break;
                    case 02:
                        if (data[11] > io.Length)
                        {
                            IllegalAddress(data);
                        }
                        else
                        { 
                            ReadDiscreteInput(data);
                        }
                        break;
                    default:
                        IllegalFunction(data);
                        break;
                }
           // }
        }
        private byte[] CreateHeader(byte high, byte low, byte length, byte function)
        {
            // byte[]	data	= new byte[9];
            List<byte> data = new List<byte>();

            //	byte[] _id = BitConverter.GetBytes((short) id);
            data.Add(high);       // Slave id high byte
            data.Add(low);       // Slave id low byte				
            data.Add(0);                    //protocol
            data.Add(0);                    //protocol
            data.Add(0);                    // Message size
            data.Add(0);					// Message size   [5]
            data.Add((byte)Port);			// Slave address     device id  [6]
            data.Add(function);             // Function code     [7]
            if (function == 5)
            {
                data.Add(0);                 //[8]
            }
            else
            {
                byte len = (byte)(length / 8 + (length % 8 > 0 ? 1 : 0));//要回复的字节个数
                data.Add(len);				// length of data to read    [8]  
                data[5] = (byte)(len + 3);
            }
            byte[] senddata = (byte[])data.ToArray();
            string sendMes = BitConverter.ToString(senddata).Replace('-', ' ');
            return senddata;
        }
        private void ReadCoils(byte[] recData)   //function code 1
        {
            // byte high,byte low, byte startAddress, byte length, byte function
            byte[] header = CreateHeader(recData[0], recData[1], recData[11], recData[7]);
            List<byte> sendData = new List<byte>();
            sendData.AddRange(header);
            string d = null;
            //读取相应的IO值  低高位
            
            for (int i = recData[9]; i < recData[9] + recData[11]; i++)
            {
                d = d + Convert.ToString(io[i].Value);
            }
            
            //二进制字符串转字节数组
            byte[] rdata = BinStringToByteArray(d);
            sendData.AddRange(rdata);
            if(recData[6]==Port)
            {
                SlaveServer.SendByteArr(sendData.ToArray());
                string sendMes = BitConverter.ToString(sendData.ToArray()).Replace('-', ' ');
                log.WriteLog("send data:" + sendMes);
            }
            
        }
        private void ReadDiscreteInput(byte[] recData)
        {
            //byte high, byte low, int startAddress, byte length, byte function
            byte[] header = CreateHeader(recData[0], recData[1], recData[11], recData[7]);
            List<byte> sendData = new List<byte>();
            sendData.AddRange(header);
            string d = null;
            //读取相应的IO值   低高位
            for (int i = recData[9]; i < recData[9] + recData[11]; i++)
            {
                d = d + Convert.ToString(io[i].Value);
            }
            
            //二进制字符串转字节数组 
            byte[] rdata = BinStringToByteArray(d);
            sendData.AddRange(rdata);
            if(recData[6]==Port)
            {
                SlaveServer.SendByteArr(sendData.ToArray());
                string sendMes = BitConverter.ToString(sendData.ToArray()).Replace('-', ' ');
                log.WriteLog("send data:" + sendMes);
            }
           
        }
        private void WriteCoil(byte[] recData)
        {
            //byte high, byte low,byte byteLen,byte address,byte value
            byte[] writeCoilData = new byte[12];
            writeCoilData[0] = recData[0];
            writeCoilData[1] = recData[1];
            writeCoilData[2] = 0;
            writeCoilData[3] = 0;
            writeCoilData[4] = 0;
            writeCoilData[5] = recData[5];
            writeCoilData[6] = (byte)Port;
            writeCoilData[7] = 5;
            writeCoilData[8] = 0;
            writeCoilData[9] = recData[9];

            writeCoilData[10] = recData[10];
            if (recData[10] == 255)//
            {
                io[recData[9]+56].Value = 1;
            }
            else if (recData[10] == 0)
            {
                io[recData[9]+56].Value = 0;
               
            }
            //if (UpdateUI != null)
            //{
            //    this.UpdateUI(io);
            //}
            writeCoilData[11] = 0;
            if(recData[6]==Port)
            {
                SlaveServer.SendByteArr(writeCoilData);
                string sendMes = BitConverter.ToString(writeCoilData).Replace('-', ' ');
                log.WriteLog("send data:" + sendMes);
            }
        }
        private void IllegalFunction(byte[] recData)
        {
            byte[] senddata = new byte[9];
            senddata[0] = recData[0];
            senddata[1] = recData[1];
            senddata[5] = 3;
            senddata[6] = (byte)Port;
            senddata[7] = (byte)(128 + recData[7]);
            senddata[8] = 1;
            SlaveServer.SendByteArr(senddata);
            string sendMes = BitConverter.ToString(senddata).Replace('-', ' ');
            log.WriteLog("send data:" + sendMes);
        }
        private void IllegalAddress(byte[] recData)
        {
            byte[] senddata = new byte[9];
            senddata[0] = recData[0];
            senddata[1] = recData[1];
            senddata[5] = 3;
            senddata[6] = (byte)Port;
            senddata[7] = (byte)(128 + recData[7]);
            senddata[8] = 2;
            SlaveServer.SendByteArr(senddata);
            string sendMes = BitConverter.ToString(senddata).Replace('-', ' ');
            log.WriteLog("send data:" + sendMes);
        }
        /// <summary>
        /// 初始化IO   反序列化
        /// </summary>
        public void LoadDataFromXML(int count)
        {
            CollectionIO ioarr = XMLSerializer.Deserialize(typeof(CollectionIO), File.OpenRead(System.Environment.CurrentDirectory + "\\config.xml")) as CollectionIO;
            int i = 0;
            foreach (ModbusIO modbus in ioarr.ios)
            {
                if (i == count)
                { break; }
                io[i].Name = modbus.Name;
                io[i].Value = modbus.Value;
                i++;
            }
           
            log.WriteLog("初始化成功！！");

        }
        /// <summary>
        /// IO二进制字符串（由低位到高位）转字节数组
        /// </summary>
        /// <param name="s">二进制字符串</param>
        /// <returns>字节数组</returns>
        private byte[] BinStringToByteArray(string s)
        {

            int len = s.Length / 8 + (s.Length % 8 > 0 ? 1 : 0);
            byte[] encodebyte = new byte[len];

            for (int i = 0; i < len; i++)
            {
                if (s.Length % 8 > 0 && i == len - 1)
                {
                    string ss = s.Substring(i * 8, s.Length % 8);
                    char[] charArr = ss.ToCharArray();
                    Array.Reverse(charArr);
                    string res = new string(charArr);
                    encodebyte[i] = Convert.ToByte(res, 2);
                }
                else
                {
                    string ss = s.Substring(i * 8, 8);
                    char[] charArr = ss.ToCharArray();
                    Array.Reverse(charArr);
                    string res = new string(charArr);
                    encodebyte[i] = Convert.ToByte(res, 2);
                }
            }
            return encodebyte;
        }
    }
}
