﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace SlaveADAM_modbusTCPIPv1._2
{
    public class SocketServer
    {
        public static bool connected = false;
        private Socket server;
        private Socket client;

        public SocketServer(string ip, int port)
        {
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //开始监听
            server.Bind(new IPEndPoint(IPAddress.Parse(ip), port));
            try
            {
                //设同一时刻可以连接的客户端个数
                server.Listen(1);
                client = server.Accept();
                connected = true;
                while (!connected)
                {
                    client = server.Accept();
                    if (client != null)
                    {
                        connected = true;
                    }
                }
            }
            catch { }
        }

        /// <summary>
        /// 接收数据，返回字节数组
        /// </summary>
        /// <returns>字节数组</returns>
        public byte[] ReceiveDataReturnByteArr()
        {
            byte[] data = new byte[12];
            client.Receive(data);

            return data;
        }
        /// <summary>
        /// 以字节数组形式发送数据
        /// </summary>
        /// <param name="data">字节数组</param>
        public void SendByteArr(byte[] data)
        {
            client.Send(data);
        }
    }
}
