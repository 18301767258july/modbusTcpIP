﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace SlaveADAM_modbusTCPIPv1._2
{
    public partial class Form1 : Form
    {
        List<TextBox> gbxIO = new List<TextBox>();
        int iocount = 62;
        Robot robot=new Robot();
        
        public Form1()
        {
            InitializeComponent();
            robot.ReceiveUI += new Action<ModbusIO[]>(SendUIDataToRobot);
            robot.UpdateUI+= new Action<ModbusIO[]>(UpdateData);
            
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            cbxStartStation.SelectedIndex = 0;
            cbxToStation.SelectedIndex = 0;
        }

        private void DisplayIOCount(int num)
        {
            for (int i = 0; i < num; i++)
            {
                int row = i / 10;
                int column = i % 10;
                GroupBox gbx = new GroupBox();
                gbx.SetBounds(7 + column * 100, 45 * row, 90, 40);
                Label cb = new Label();
                TextBox tb = new TextBox();
                cb.Text = "IO" + i.ToString() + ":";
                cb.SetBounds(0, 17, 35, 20);
                cb.Left = 10;
                tb.Text = "";

                tb.KeyPress += LimitInput;
                tb.SetBounds(45, 13, 30, 25);
                gbx.Controls.Add(cb);
                gbx.Controls.Add(tb);
                gbxIO.Add(tb);
                groupBox1.Controls.Add(gbx);
            }
        }

        private void btnConnect_Click_1(object sender, EventArgs e)
        {
            DisplayIOCount(iocount);
            robot.Connect(tbxIP.Text, Convert.ToInt32(tbxID.Text));
        }
       
        void UpdateData(ModbusIO[] value)
        {
            //跨线程    
            for (int i = 0; i < iocount;i++ )
            {
                if (gbxIO[i].InvokeRequired)
                {
                    Action<int> actionDelegate = (x) => { this.gbxIO[i].Text = x.ToString(); };
                    this.gbxIO[i].Invoke(actionDelegate, value[i].Value); 
                }
                else
                {
                    gbxIO[i].Text = value[i].Value.ToString();
                }
            }
        }


        void SendUIDataToRobot(ModbusIO[] data)
        {
            for(int i=0;i<iocount;i++)
            {
                data[i].Value = Convert.ToInt32(gbxIO[i].Text);
            }
            
        }
        public void LimitInput(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar != 48 && e.KeyChar != 49)
            {
                e.Handled = true;
                MessageBox.Show("输入有误，请重新输入！");

            }
            else
            {
                e.Handled = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            robot.startStation=cbxStartStation.Text;
            robot.startNum=Convert.ToInt32(tbxStartNum.Text);
            robot.toStation=cbxToStation.Text;
            robot.toNum=Convert.ToInt32(tbxToNum.Text);
            Thread thread = new Thread(new ThreadStart(robot.Action));
            thread.IsBackground = true;
            thread.Start();
            
        }


      
    }
    
}
