﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;

namespace SlaveADAM_modbusTCPIPv1._2
{
    public class ModbusIO
    {
        public string Name
        {
            get;
            set;
        }

        public int Value
        {
            get;
            set;
        }
    }
    public class CollectionIO
    {
        [XmlArrayItem("ModbusIO")]
        public ModbusIO[] ios { get; set; }
    }
}
