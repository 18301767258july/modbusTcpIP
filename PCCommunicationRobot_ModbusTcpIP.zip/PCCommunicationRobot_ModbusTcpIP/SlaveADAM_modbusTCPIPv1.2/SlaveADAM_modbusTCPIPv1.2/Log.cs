﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace SlaveADAM_modbusTCPIPv1._2
{
    public class Log
    {
        string filepath;
        string fileName = DateTime.Now.ToString("yyyyMMdd") + ".log";

        public Log()
        {
            if (!File.Exists(System.Environment.CurrentDirectory + "\\" + fileName))
            {
                string path = System.Environment.CurrentDirectory;
                System.IO.Directory.CreateDirectory(path);
                this.filepath = System.IO.Path.Combine(path, fileName);
                FileStream file = File.Create(filepath);
                file.Close();
            }

        }
        public void WriteLog(string text)
        {
            text = text + "\r\n";
            using (StreamWriter write = new StreamWriter(System.Environment.CurrentDirectory + "\\" + fileName, true, Encoding.UTF8))
            {
                write.Write(DateTime.Now.ToString("[yyyy-MM-dd HH:mm:ss") + "." + DateTime.Now.Millisecond.ToString() + "] " + text);

            }
        }
    }
}
